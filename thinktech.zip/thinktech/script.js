$(".navigation a").click(function () {
  $(".navigation").removeClass('open');
});
